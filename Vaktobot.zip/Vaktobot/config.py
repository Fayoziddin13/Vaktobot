BOT_TOKEN = "7904938558:AAG-Qkhxa9D39Cy-b9v5skNYRwW1odIVsno"
ADMIN_IDS = [5317297079]  # Иш бошқарувчилар Telegram ID лари